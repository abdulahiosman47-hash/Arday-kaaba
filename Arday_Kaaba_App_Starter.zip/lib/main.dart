import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

void main() => runApp(const ArdayKaabaApp());

class ArdayKaabaApp extends StatelessWidget {
  const ArdayKaabaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Arday Kaaba',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Arday Kaaba'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), color: Theme.of(context).colorScheme.primaryContainer),
            child: const Column(children: [
              Icon(Icons.school_rounded, size: 70),
              SizedBox(height: 10),
              Text('Arday Kaaba', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text('Baro meel kasta — Offline', style: TextStyle(fontSize: 16)),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('Maaddooyinka', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.biotech)), title: const Text('Biology'), subtitle: const Text('Questions & Answers'), trailing: const Icon(Icons.arrow_forward_ios), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PdfPage(title: 'Biology', asset: 'assets/pdfs/biology.pdf'))))),
          Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.menu_book)), title: const Text('Maaddooyin kale'), subtitle: const Text('PDF-yada cusub ayaa lagu dari karaa'), trailing: const Icon(Icons.lock_outline))),
        ],
      ),
    );
  }
}

class PdfPage extends StatelessWidget {
  final String title;
  final String asset;
  const PdfPage({super.key, required this.title, required this.asset});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(title)), body: SfPdfViewer.asset(asset));
  }
}
