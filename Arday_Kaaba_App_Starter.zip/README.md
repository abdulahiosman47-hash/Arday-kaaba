# Arday Kaaba

Offline Android learning app starter for Somali students.

## Included
- Arday Kaaba home screen
- Biology PDF bundled inside the app
- Offline PDF reader
- Structure ready for additional subjects and quizzes

## Build
Install Flutter, then run:

    flutter pub get
    flutter build apk --release

The generated APK will be under build/app/outputs/flutter-apk/release/.
